'use strict';
var walletService = function() {
	return {
        wallet: null,
        password:''
    }
};
module.exports = walletService;